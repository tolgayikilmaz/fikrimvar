﻿	var SERVICEURL = "http://gbuspdt02/search.api/";
	var searchnavstate=new Array();
	var currentSouce = "";
	var currentpage=1;
	var ongoogle = 0;
	var currentkeyword='';
	history.navigationMode='compatible';
	var autocompletedata=null;
	$(document).ready(function(){
		SearchInit();
		var now = new Date();
		var d=FormatDate(now);
		$('#spancurrentdate').empty();
		$('#spancurrentdate').append(d);
		$.address.externalChange(function(e){
			var p=queryString('p');
			if (p!=null){
				currentkeyword=$.base64Decode(p);
				$('#searchinput').val(currentkeyword);
			}
			
			var n=queryString('n');
			if (n!=null){
				var nav=$.base64Decode(n);
				nav=nav.replace(/"/g,'');
				nav=nav.split("+");
				ResetActiveByNavState();
				$(nav).each(function (properties, val) {
					var x=val.split(":");
					var nx=x[0].rtrim();
					var mx=x[1].rtrim();
					SetActiveByNavState(nx,mx);
				});
			}
			
			var s=queryString('s');
			if (s!=null){
				currentpage=$.base64Decode(s);
			}
			ClearAndRefillAllNavigations();
			
			var curds=FindActiveDataSource();
			if (curds!=null && curds.message!=null && curds.message!=undefined && curds.message!='' && curds.message!="null"){
				RenderMessage(curds.message);
			}
			else{
				Search();
			}
			$("#infodiv").empty();
		});
		
		$("#searchicon").click(function(event)
	    {
	    	var keyword = document.getElementById("searchinput").value;
	    	if (keyword=='' || keyword=='undefined')
		     	return;
		    searchnavstate=new Array();
		    $("#navigatorul").empty();
		    currentkeyword=keyword;
		    document.location.hash = "#p="+$.base64Encode(currentkeyword);
		    currentpage=1;
	    });

		$('#searchinput').focus();
		$('#searchinput').keyup(function(event) {
		  if (event.keyCode == '13') {
		     var keyword=this.value;
		     if (keyword=='' || keyword=='undefined')
		     	return;
		     searchnavstate=new Array();
		     $("#navigatorul").empty();
		     currentkeyword=keyword;
		     document.location.hash = "#p="+$.base64Encode(currentkeyword);
		     currentpage=1;
		   }
		});
	});
	
	function RenderMessage(msg){
		var html=''; 
		html+="<h2><center>"+msg+"</center></h2>";
		$("#infodiv").empty();
		$("#pagingul").empty();
		$("#searchresultdiv").empty();
        $("#searchresultdiv").append(html);
	};
	
	function FindActiveDataSource(){
		var result=null;
		$(searchnavstate).each(function (pproperties, pval) {
			if (pval.nav=="datasource" && pval.isactive){
				result=pval;
				return false;
			}
		});
		return result;
	}
	
     function Search() {
     	ShowIndicator();
         var query="p=" + $.base64Encode(currentkeyword);
         if (searchnavstate.length>0){
         	var snav='';
         	var inav=0;
         	$(searchnavstate).each(function (properties, val) {
				if (val.isactive){
					if (inav>0){
						snav+="+";
					}
					snav+=val.nav + ":" + '"' + val.mod + '" ';
					inav++;
				}
			});

         	if (snav!='' && snav!=null && snav!=undefined){
         		if(snav.toLowerCase().indexOf("google")>-1)
         			ongoogle = 1;
         		else
         			ongoogle = 0;
         		query+="&n=" + $.base64Encode(snav);   
         	}
         }
         query+="&s=" + currentpage;
         //document.location.hash=query;
         $.ajax({
             type: "GET", //GET or POST or PUT or DELETE verb
             url: SERVICEURL + "search", 
             data: query,
             contentType: "application/json", // content type sent to server
             dataType: "json", //Expected data format from server
             processdata: false, //True or False
             complete: function (data) {
                 RenderNavigators(data);
                 RenderResults(data);
                 $("#pagingdiv").show();
                 RenderPaging(data);
                 $("#s4-workspace").animate({scrollTop : 0},500); 
             }                 
         });             
     }
     
	function RenderNavigators(data){
		var navhtml=''; 
		var obj= jQuery.parseJSON(data.responseText);
		var ncur=0;
		var sr=obj.SearchResult;
         $(sr.Navigators).each(function (properties, val) {
          	if (ncur==0)  
	            navhtml+="<li class='selected'>";
	        else
	        	navhtml+="<li>";
            navhtml+="<a class='sprite' ><span>"+val.DisplayName+"</span></a>";
			navhtml+="<ul class='clearfix'>";
					//if (val.DisplayCount>0){
					//	navhtml+="<div class='scroll scroll-type1'>";
					//	navhtml+="<div class='nav-issues'>";
					//}
					var mi=0;
					var first=true;
					$(val.Points).each(function (pproperties, pval) {
						var modid='mod_' + val.Modifier + '_' + pval.Name;
						modid=modid.replace(/ /g,'');
						//var modid=pval.Id;
						var mcount=pval.Count>0?FormatNumberBy3(pval.Count,",", "."):'';
						mi++;
						if (val.DisplayCount>0 && mi>val.DisplayCount){
							if (first){
								navhtml+="<li onclick='ShowHiddenNavigators(this);'><a class='clearfix' ><span class='showmore' style='float:right;'>Devamı</span><b></b></a></li>";
								first=false;
							}
							if (pval.ImageUrl=='' || pval.ImageUrl==undefined || pval.ImageUrl==null){
								navhtml+="<li class='navhide' id='"+ modid +"' onclick='AddNavigator(this);' nav='"+val.Modifier+"' mod='"+pval.Name+"' desc='"+pval.Description+"' msg='"+pval.Message+"' ><a class='clearfix' ><span>"+pval.Description+"</span><b>"+mcount+"</b></a></li>";
							}
							else{
								navhtml+="<li class='navhide' id='"+ modid +"' onclick='AddNavigator(this);' nav='"+val.Modifier+"' mod='"+pval.Name+"' desc='"+pval.Description+"' msg='"+pval.Message+"' imgurl='"+pval.ImageUrl+"' ><a class='clearfix' ><img src='"+pval.ImageUrl+"'/><b>"+mcount+"</b></a></li>";
							}
						}
						else{
							if (pval.ImageUrl=='' || pval.ImageUrl==undefined || pval.ImageUrl==null){
								navhtml+="<li id='"+ modid +"' onclick='AddNavigator(this);' nav='"+val.Modifier+"' mod='"+pval.Name+"' desc='"+pval.Description+"' msg='"+pval.Message+"' ><a class='clearfix'><span>"+pval.Description+"</span><b>"+mcount+"</b></a></li>";
							}
							else
							{
								navhtml+="<li id='"+ modid +"' onclick='AddNavigator(this);' nav='"+val.Modifier+"' mod='"+pval.Name+"' desc='"+pval.Description+"' imgurl='"+pval.ImageUrl+"' msg='"+pval.Message+"' ><a class='clearfix'><img style='height:18px;weight:60px;' src='"+pval.ImageUrl+"'/><b>"+mcount+"</b></a></li>";
							}
						}
						
					});
			//if (val.DisplayCount>0){
			//	navhtml+="</div></div>";
			//}
	
			navhtml+="</ul>";
			navhtml+="<div class='sprite box-corner'><span>&nbsp;</span></div>";
			navhtml+="</li>";
			ncur++;
         });
        $("#navul").empty();
        $("#navul").append(navhtml);
        

	    if ($("div.scroll div.nav-issues").length > 0) {
			$("div.scroll div.nav-issues").jScrollPane();
		}
		if(sr.CurrentDataSource != null && sr.CurrentDataSource != '')
		{
            var cnav=sr.CurrentDataSource;
            var modid='mod_datasource_' + cnav.Name;
			modid=modid.replace(/ /g,'');
            var onav=new Object();
			onav.nav="datasource";
			onav.mod=cnav.Name;
			onav.desc=cnav.Description;
			onav.id=modid;
			onav.isactive=true;
			searchnavstate.push(onav);						
			AddNavigatorHtml(onav);
		}
		
		$(searchnavstate).each(function (pproperties, pval) {
			if (pval.isactive){
				var elid=pval.id;
				var el=$('#'+elid);
				$(el).attr("style","background-color:#C9C9C9;");
				$(el).parent().parent().addClass('selected');
			}
		});

	}
	
	function AddNavigator(li){
		var onav=new Object();
		onav.nav=$(li).attr('nav');
		onav.mod=$(li).attr('mod');
		onav.desc=$(li).attr('desc');
		onav.id=$(li).attr('id');
		onav.imageurl=$(li).attr('imgurl');
		onav.message=$(li).attr('msg');
		onav.isactive=true;
		if (onav.nav=='datasource'){
			//ResetActiveDataSource();
			ResetActiveByNavState();
		}
		
		if (!HasInNavState(onav)){				
			searchnavstate.push(onav);
		}
		ClearAndRefillAllNavigations();					
		currentpage=1;			
		var snav="";
		var inav=0;
		$(searchnavstate).each(function (properties, val) {
			if (val.isactive){
				if (inav>0){
					snav+="+";
				}
				snav+=val.nav + ":" + '"' + val.mod + '" ';
				inav++;
			}
		});				
		document.location.hash = "#p="+$.base64Encode(currentkeyword)+"&n="+$.base64Encode(snav);
	};
	
	function ResetActiveDataSource(){
		$(searchnavstate).each(function (pproperties, pval) {
			if (pval.nav=="datasource"){
				pval.isactive=false;
			}
		});
	}
	
	function HasInNavState(onav){
		var result=false;
		$(searchnavstate).each(function (pproperties, pval) {
			/*
			if (onav.nav=='datasource' && pval.nav=="datasource"){
				//searchnavstate.splice(pproperties,1);
				result = true;
				return false;
			}
			*/
			if (pval.nav==onav.nav && pval.mod==onav.mod){
				result=true;
				pval.isactive=true;
				return false;
			}				
		});
		return result;
	
	};
	
	function AddNavigatorHtml(onav){
		if (!onav.isactive)
			return;
		var newnavhtml='';
		if (onav.imageurl=='' || onav.imageurl==undefined || onav.imageurl==null){
			newnavhtml+="<li onclick='RemoveNavigator(this)' nav='"+onav.nav+"' mod='"+onav.mod+"';><a ><span>"+onav.desc+"</span></a></li>";
		}
		else{
			newnavhtml+="<li onclick='RemoveNavigator(this)' nav='"+onav.nav+"' mod='"+onav.mod+"';><a ><span><img style='height:18px;weight:60px;' src='"+onav.imageurl+"'/></span></a></li>";
		}
		$("#navigatorul").append(newnavhtml);
		currentSouce = onav.mod;
	}
	
	function ClearAndRefillAllNavigations()
	{
		$("#navigatorul").empty();			
		$(searchnavstate).each(function (pproperties, pval) {
			if (pval.isactive){
				AddNavigatorHtml(pval);
			}					
		});
	}
	
	function RemoveNavigator(li){
		var nav=$(li).attr('nav');
		var mod=$(li).attr('mod');
		var inav=0;
		$(searchnavstate).each(function (properties, val) {
			if (val.nav==nav && val.mod==mod){
				val.isactive=false;
			}
			inav++;
		});
		ClearAndRefillAllNavigations();
		currentpage=1;
		var snav="";
		var inav=0;
		$(searchnavstate).each(function (properties, val) {
			if (val.isactive){
				if (inav>0){
					snav+="+";
				}
				snav+=val.nav + ":" + '"' + val.mod + '" ';
				inav++;
			}
		});				
		document.location.hash = "#p="+$.base64Encode(currentkeyword)+"&n="+$.base64Encode(snav);
	}
	
	function ShowHiddenNavigators(el){
		$(el).parent().children().each(function (properties, val) {
			$(val).removeAttr("class");
		});
		$(el).remove();
	}
	
	function RenderResults(data){
		var reshtml=''; 
		var obj= jQuery.parseJSON(data.responseText);
		var suggestHTML = '';
		var sr=obj.SearchResult
                 $(sr.DocList).each(function (properties, val) {
                  	var title=val.FieldCollection[0].Value;
                  	if(title == null || title == "undefined")
                  		title = "Doküman";
                  	var teaser=val.FieldCollection[1].Value;
                  	if(teaser == null || teaser == "undefined")
                  		teaser = "";
                  	var url=val.FieldCollection[2].Value;
                  	var size=val.FieldCollection[3].Value;
                  	if (parseInt(size)>0){
                  		size=parseInt(size)/1024;
                  		size=parseInt(size);
                  	}
                  	var cdate=StrToDate(val.FieldCollection[4].Value);
                  	var enddate = null ;
                  	var isFinished = 0;
                  	var enddatestr = null;
                  	if(val.FieldCollection[5].Value != null)
                  	{
                  		enddatestr = StrToDate(val.FieldCollection[5].Value);
                  		var enddate = DateToNumber(val.FieldCollection[5].Value);
                  		//enddate = new Date(enddate.getFullYear(),enddate.getMonth(),enddate.getDate());
                  		var today = new Date();
                  		today=today.format("yyyyMMdd");
                  		today=parseInt(today);                      		
                  		if(today > enddate)
                  			isFinished = 1;
                  	}
                  	var surl=val.FieldCollection[6].Value;
                    reshtml+="<div class='search-item'>";
                    reshtml+="<h3><a href='"+surl+"'>"+title+"</a>";
                    if(isFinished)
                    	reshtml += "<img style='padding-left:10px' src='SiteAssets/images/over.gif'/> <span style='font-size:small'>Kampanya Bitti</span>";
                    reshtml += "</h3>" 
					reshtml+="<p>"+teaser+"</p>";
					reshtml+="<span class='search-item-detail'>";
					if(currentSouce == "Internet" || currentSouce == "Google")
						reshtml+="<a href='outsite.aspx?url="+surl+"'>" + url + "</a>";
					else
						reshtml+="<a href='"+surl+"'>" + url + "</a>";
					if (size!='' && cdate!=''){
						reshtml+="<b>- "+size+" KB - "+cdate+"</b>";
					}
					if(enddate != null)
					{
						reshtml += "<br/>Kampanya bitiş tarihi: <b>"+ enddatestr +"</b>";
					}
					reshtml+="</span></div>";
                 });
                 
        $(sr.Suggestions).each(function (properties, val) 
        {
        	suggestHTML ="<br/><span><a style='cursor:pointer' onclick=\"suggestedSearch('"+val +"')\"><b>" + val + "</b></a> mi demek istediniz?";
        })
        $("#searchresultdiv").empty();
        $("#searchresultdiv").append(reshtml);
        
        $(currentkeyword.replace("*","").split(" ")).each(function (properties, val) {
			$("#searchresultdiv").highlight(val);  
		});
        
        var infohtml="<span><b>" + currentkeyword + "</b> kelimesi için yaklaşık "+ FormatNumberBy3(sr.DocCount,",", ".") +" sonuç";
        if (sr.Duration!=''){
        	infohtml+=" ("+ sr.Duration +" saniye)";
        }
		infohtml+="</span>";
        $("#infodiv").empty();
        $("#infodiv").append(infohtml);
        if(suggestHTML != '')
        {
        	 $("#infodiv").append(suggestHTML);
        }	
	}
	function suggestedSearch(kyw)
	{
		currentkeyword = kyw;
		Search();
		$('#searchinput').val(currentkeyword);
		document.location.hash = "#q="+kyw;
	}
	
	function RenderPaging(data){
		var obj= jQuery.parseJSON(data.responseText);
		var sr=obj.SearchResult;
		var pcount=sr.PageCount;
		var paginghtml='';
		if (currentpage>1){
			var prevpage=parseInt(currentpage)-1;
			paginghtml+="<li class='prev' pi='"+prevpage+"' onclick='ShowPage(this)'><a>&lt;&lt; Önceki</a></li>";		
		}
		
		var pi=parseInt(currentpage)-(parseInt(currentpage)%8);
		if (pi==0)
			pi++;
		var takecount=0;
		var restcount=parseInt(pcount)- parseInt(currentpage);
		if (pcount>8){
			takecount=(parseInt(currentpage)+8)-(parseInt(currentpage)%8);		
		}
		else{
			takecount=pcount;
		}
		
		while(pi<=pcount){
			if (pi==currentpage){
				paginghtml+="<li pi='"+pi+"' onclick='ShowPage(this);'><a class='selected' >"+pi+"</a></li>";
			}
			else{
				paginghtml+="<li pi='"+pi+"' onclick='ShowPage(this);'><a >"+pi+"</a></li>";
			}
			
			
			if (pi>=takecount){
				break;
			}
			pi++;
		};
		
		if (currentpage<pcount){
			var nextpagenum=parseInt(currentpage)+1;
			paginghtml+="<li class='next' pi='"+nextpagenum+"' onclick='ShowPage(this)' ><a >Sonraki &gt;&gt;</a></li>";
		}
		$("#pagingul").empty();
        $("#pagingul").append(paginghtml);
	}
     
     function ShowPage(li){
		currentpage=$(li).attr('pi');
		Search();
     }
     
     function StrToDate(utcString) {
    			var year1  = utcString.substr(2,2);  
				var month1= utcString.substr(5,2);
				var day1= utcString.substr(8,2);  
				var time1= utcString.substr(11,5);
				return  (day1+ "." +month1 + "." + year1+ " " +time1);
	}
	
	function DateToNumber(utcString) {
		var year1  = utcString.substr(0,4);  
		var month1= utcString.substr(5,2);
		var day1= utcString.substr(8,2);  
		var r=(year1  + "" +month1 + "" + day1);
		return parseInt(r);
	}
	
	function ShowIndicator()
	{
		var html="";
		html+="<div class='loading'><center><img src='../../Style Library/assets/image/waitanimation.gif'/></center></div>";
		$("#searchresultdiv").empty();
        $("#searchresultdiv").append(html);
        $("#pagingdiv").hide();
	}
	
     function FormatDate(d){
     	var m_names = new Array("OCAK", "ŞUBAT", "MART","NİSAN", "MAYIS", "HAZİRAN", "TEMMUZ", "AĞUSTOS", "EYLÜL","EKİM", "KASIM", "ARALIK");
		var curr_date = d.getDate();
		var curr_month = d.getMonth();
		var curr_year = d.getFullYear();
		return '{0} {1} {2}'.format(curr_date, m_names[curr_month], curr_year);
     
     }
     
     String.prototype.format = function() {
		var txt = this,
    	i = arguments.length;
		while (i--) {
    		txt = txt.replace(new RegExp('\\{' + i + '\\}', 'gm'), arguments[i]);
		}
		return txt;
	};

    function queryString(val) {
	  	var result =null;
	  	var url=window.location.hash;
	    var regEx = new RegExp("[\\#&]"+val+"=([^&#]*)")
	    //var regEx = new RegExp(/(\\?|&)(val=)(.*?)(&|$|#)/g)
	    //var regEx = new RegExp("(\\?|&)("+val+"=)(.*?)(&|$|#)","i")
	    var exec = regEx.exec(url)
	    if (exec!=null){
	    	result = exec[1];
	    }
	
	  return(result)
	}
	
	function ResetActiveByNavState(){
		var result=null;
		$(searchnavstate).each(function (pproperties, pval) {
			pval.isactive = false;
		});
	};

	
	function SetActiveByNavState(nav,mod){
		var result=null;
		$(searchnavstate).each(function (pproperties, pval) {
			if (pval.nav==nav && pval.mod==mod){
				pval.isactive = true;
				return true;
			}				
		});
	};
	
	String.prototype.trim = function() {
		return this.replace(/^\s+|\s+$/g,"");
	}
	
	String.prototype.ltrim = function() {
		return this.replace(/^\s+/,"");
	}
	
	String.prototype.rtrim = function() {
		return this.replace(/\s+$/,"");
	}
	
	function ParseAutoComplete(data){
	 	var obj= jQuery.parseJSON(data.responseText);
		var sr=obj.SearchInitResult;
	 	var autocomplete=new Array();
	 	var autocompletefull = new Array();//autocompletee array with full parameters
	 	var i=0;
	 	$(sr).each(function (properties, val) {
	 		autocomplete[i]=val.Keyword;
	 		autocompletefull[i] = val;
	 		i++;
	 	});
	 	autocompletedata=autocomplete;
	 	BindAutoComplete(autocomplete);
	 }
 
	 function BindAutoComplete(data){
		 $('#searchinput').autocomplete({
			minChars: 0,
			delimiter: /(,|;)\s*/, // regex or character
			maxHeight: 130,
			zIndex: 9999,
			deferRequestBy: 0, //miliseconds
			noCache: false, //default is false, set to true to disable caching
			autoFill:true,
			// callback function:
			onSelect: function (value, data) { 
				var redirect=false;
				for(var i = 0; i<autocompletedata.length; i++)
				{
					if(value == autocompletedata[i].Keyword && autocompletedata[i].Url != '' && autocompletedata[i].Url != null)
					{
						location.href = autocompletedata[i].Url;
						redirect=true;
						break;
					}   
				}
				if (!redirect){
					searchnavstate=new Array();
				    $("#navigatorul").empty();
				    currentkeyword=value;
				    document.location.hash = "#p="+$.base64Encode(currentkeyword);
				    currentpage=1;
				}
			},
			lookup: data
		});	
	 }
	 
	 function SearchInit(){
		$.ajax({
		     type: "GET", //GET or POST or PUT or DELETE verb
		     url: SERVICEURL + "searchinit", 
		     data: null,
		     contentType: "json", // content type sent to server
		     dataType: "json", //Expected data format from server
		     processdata: false, //True or False
		     complete: function (data) {
		        ParseAutoComplete(data); 
		     }
		 });
	}

	
	
