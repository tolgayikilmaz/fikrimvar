﻿var menudata=null;
$(document).ready(function () {
	LoadMenu();
	$('#txtsearchmenu').keyup(function(event) {
			  if (event.keyCode != '13') {
			     var keyword=this.value;
			     if (keyword=='' || keyword=='undefined'){
			     	$("#searchmenu").empty();
			     	return;
			     }
			     SearchMenu(keyword);
			   }
			});

});

var SERVICEURL = "http://gbuspdt02/menu.api/";
function LoadMenu(){
	$.ajax({
	     type: "GET", //GET or POST or PUT or DELETE verb
	     url: SERVICEURL + "load", 
	     data: null,
	     contentType: "json", // content type sent to server
	     dataType: "json", //Expected data format from server
	     processdata: false, //True or False
	     complete: function (data) {
	         var obj= jQuery.parseJSON(data.responseText);
	         if (obj.status_code=='200'){
	         	menudata=obj.data;
	         	RenderFavorites();
			 }
			 else{
				alert(obj.status_code+ ': ' + obj.status_txt);
			 }
	     },
         error: function (xhr) {
           alert(xhr.status + ': ' + xhr.statusText);
        } 
	 });
}

function RenderFavorites(){
	var adminfavhtml='';
	var myfavhtml='';
	$(menudata).each(function (properties, val) {
    	var title=val.title;
    	if (val.title.length>20){
    		title=title.substr(0,16);
    		title=title+' ...';
    	}
    	if (val.menutype==0 && val.isfavorite){
    		myfavhtml+="<li class='active clearfix'><a class='favorite' href='app.aspx?m="+val.moduleid+"&e="+val.menuid+"' title='"+val.title+"'>" + title + "</a><a class='action' href='#' moduleid="+val.moduleid+" menuid="+val.menuid +" menutype='fav'>Çıkar</a></li>";
		}
		else if (val.menutype==2){
			if (val.isfavorite){
    			adminfavhtml+="<li class='active clearfix'><a class='favorite' href='app.aspx?m="+val.moduleid+"&e="+val.menuid+"'  title='"+val.title+"'>" + title + "</a><a class='action' href='#' moduleid="+val.moduleid+" menuid="+val.menuid +" menutype='fav'>Çıkar</a></li>";
			}
			else{
				adminfavhtml+="<li class='deactive clearfix'><a class='unfavorite' href='app.aspx?m="+val.moduleid+"&e="+val.menuid+"'  title='"+val.title+"'>" + title + "</a><a class='action' href='#' moduleid="+val.moduleid+" menuid="+val.menuid +" menutype='fav'>Ekle</a></li>";
			}
		}   	      		
    });
	
	$("#adminfavmenu").empty();
    $("#adminfavmenu").append(adminfavhtml);

	
	$("#myfavmenu").empty();
    $("#myfavmenu").append(myfavhtml);
    

    $("#myfavmenu li.active a.action").live('click',function(e){
    	RemoveFavorite(this);
    });
    
    $("#adminfavmenu li.active a.action").live('click',function(e){
    	RemoveFavorite(this);
    });

    
    $("#adminfavmenu li.deactive a.action").live('click',function(e){
    	AddFavorite(this);
    });

}

function SearchMenu(keyword){
	var adminfavhtml='';
	var searchhtml='';
	$(menudata).each(function (properties, val) {
    	var title=val.title;
    	if (val.title.length>20){
    		title=title.substr(0,16);
    		title=title+' ...';
    	}
    	if (val.menutype==0 && val.title.toLowerCase().indexOf(keyword) != -1){
    		if (val.isfavorite){
    			searchhtml+="<li class='active clearfix'><a class='favorite' href='app.aspx?m="+val.moduleid+"&e="+val.menuid+"'  title='"+val.title+"'>" + title + "</a><a class='action' href='#' moduleid="+val.moduleid+" menuid="+val.menuid +" menutype='search'>Çıkar</a></li>";
    		}
    		else{
    			searchhtml+="<li class='deactive clearfix'><a class='unfavorite' href='app.aspx?m="+val.moduleid+"&e="+val.menuid+"'  title='"+val.title+"'>" + title + "</a><a class='action' href='#' moduleid="+val.moduleid+" menuid="+val.menuid +" menutype='search'>Ekle</a></li>";
    		}
		}
    });
	
	$("#searchmenu").empty();
    $("#searchmenu").append(searchhtml);
    
    $("#searchmenu li.active a.action").live('click',function(e){
    	RemoveFavorite(this);
    });

    
    $("#searchmenu li.deactive a.action").live('click',function(e){
    	AddFavorite(this);
    });
    

}

function LoadModules(){
	$.ajax({
	     type: "GET", //GET or POST or PUT or DELETE verb
	     url: SERVICEURL + "loadmodules", 
	     data: null,
	     contentType: "json", // content type sent to server
	     dataType: "json", //Expected data format from server
	     processdata: false, //True or False
	     complete: function (data) {
	         var obj= jQuery.parseJSON(data.responseText);
	         if (obj.status_code=='200'){
	         	RenderModules(obj.data);
			 }
			 else{
				alert(obj.status_code+ ': ' + obj.status_txt);
			 }
	     },
         error: function (xhr) {
           alert(xhr.status + ': ' + xhr.statusText);
        } 
	 });
}

function RenderModules(data){
	var html='';
	$(data).each(function (properties, val) {
    	html+="<li><a href='#'>"+val.title+"</a>"
    	html+="<ul  style='width:auto;'>";
    	$(val.children).each(function (properties, val2) {
    		if (val2.isfavorite){
    			html+="<li class='active clearfix'><a href='#'>"+val2.title+"</a><a moduleid="+val2.moduleid+" menuid="+val2.menuid +" class='action' href='#' title='Benim Menümden Çıkar' menutype='all'>Çıkar</a></li>";
    		}
    		else{
    			html+="<li class='deactive clearfix'><a href='#'>"+val2.title+"</a><a moduleid="+val2.moduleid+" menuid="+val2.menuid +" class='action' href='#' title='Benim Menüm'e Ekle' menutype='all'>Ekle</a></li>";
    		}
    		

		});    	
    	html+="</ul>";
    	html+="</li>";
    });
    
	$("#allmenuul").empty();
    $("#allmenuul").append(html);
    
    $("#allmenuul li ul li.active a.action").live('click',function(e){
    	RemoveFavorite(this);
    });
    $("#allmenuul li ul li.deactive a.action").live('click',function(e){
    	AddFavorite(this);
    });
}

function AddFavorite(el){
	var moduleid=$(el).attr('moduleid');
	var menuid=$(el).attr('menuid');
	var menutype=$(el).attr('menutype');
	var obj=new Object();
	obj.moduleid=moduleid;
	obj.menuid=menuid;
	if (menutype=='all' || menutype=='search'){
		$(el).parent().removeClass('deactive');
		$(el).parent().addClass('active');
		$(el).text('Çıkar');
		if (menutype=='search'){
			var cha=$(el).parent().children()[0];
			$(cha).removeClass('unfavorite');
			$(cha).addClass('favorite');
		}
	}
	$.ajax({
         type: "POST", //GET or POST or PUT or DELETE verb
         url: SERVICEURL + "addfavorite", // Location of the service
         data: $.toJSON(obj),
         contentType: "application/json", // content type sent to server
         dataType: "json", //Expected data format from server
         processdata: false, //True or False
         complete: function (data) {
			var obj= jQuery.parseJSON(data.responseText);
			if (obj.status_code=='200'){
				LoadMenu();
			}
			else{
				alert(obj.status_code+ ': ' + obj.status_txt);
			}
         },
         error: function (xhr) {
           alert(xhr.status + ': ' + xhr.statusText);
        }         
     });
}

function RemoveFavorite(el){
	var moduleid=$(el).attr('moduleid');
	var menuid=$(el).attr('menuid');
	var menutype=$(el).attr('menutype');
	var obj=new Object();
	obj.moduleid=moduleid;
	obj.menuid=menuid;
	if (menutype=='all' || menutype=='search'){
		$(el).parent().removeClass('active');
		$(el).parent().addClass('deactive');
		$(el).text('Ekle');
		if (menutype=='search'){
			var cha=$(el).parent().children()[0];
			$(cha).removeClass('favorite');
			$(cha).addClass('unfavorite');
		}
	}
	$.ajax({
         type: "POST", //GET or POST or PUT or DELETE verb
         url: SERVICEURL + "removefavorite", // Location of the service
         data: $.toJSON(obj),
         contentType: "application/json", // content type sent to server
         dataType: "json", //Expected data format from server
         processdata: false, //True or False
         complete: function (data) {
			var obj= jQuery.parseJSON(data.responseText);
			if (obj.status_code=='200'){
				LoadMenu();
			}
			else{
				alert(obj.status_code+ ': ' + obj.status_txt);
			}
         },
         error: function (xhr) {
           alert(xhr.status + ': ' + xhr.statusText);
        }         
     });

}
