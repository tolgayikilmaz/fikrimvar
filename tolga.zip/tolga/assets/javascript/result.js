﻿var SERVICEURL = "http://gbuspdt02/surl.api/";
var URL = location.href


$(document).ready(function()
{
	LoadFrame(queryString("url"));
});

function LoadFrame(surl)
{

	 $.ajax({
                 type: "GET", //GET or POST or PUT or DELETE verb
                 url: SERVICEURL+"find", 
                 data: "shorturl="+ surl,
                 contentType: "application/json", // content type sent to server
                 dataType: "json", //Expected data format from server
                 processdata: false, //True or False
                 complete: function (data) {
                 	data = jQuery.parseJSON(data.responseText);
                    var div = document.getElementById("alertdiv");
                    div.innerHTML = "Bu kaynağın güvenilirliği kurumumuz tarafından onaylanmamaktadır.";
                    div.innerHTML += "Bu kaynaktan vereceğiniz her türlü bilginin sorumluluğu size aittir.";
                    div.innerHTML += "Bu kaynağın güvenilir olduğunu düşünüyorsanır Lütfen bilgi yönetim ekibine bildiriniz."
                    var frame = document.getElementById("innerframe");
                    frame.src = data.data.url;
                 }                 
             });           
}

function queryString(Deger) {
  if(Deger!=null) {
    var regEx = new RegExp("(\\?|&)("+Deger+"=)(.*?)(&|$|#)","i")
    var exec = regEx.exec(URL)
    var Sonuc = RegExp.$3
  } else {
    var regEx = new RegExp("(\\?)(.*?)($)","i")
    var exec = regEx.exec(URL)
    var Sonuc = RegExp.$2
  }

  return(Sonuc)
}