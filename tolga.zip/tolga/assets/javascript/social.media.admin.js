﻿Ext.onReady(function(){
	Ext.override(Ext.tree.TreeEditor, {
	    beforeNodeClick : function(){},
	    onNodeDblClick : function(node, e){
	            this.triggerEdit(node);
	    }
	});

	var treepanel=new FilterGroupTree(
	{
		region:'west',
        split: false,
        collapsible: false,
        width: 200,
        minSize: 100,
        maxSize: 250
	});
	
	var cmp1 = new MainPanel({
        renderTo: 'mainpaneldiv',
        items:[treepanel,
        {
	        title: 'Center Region',
	        region: 'center',     // center region is required, no width/height specified
	        xtype: 'container',
	        layout: 'fit',
	        id:'center-region-container'
    	}]
    });
    cmp1.show();
    
});


/*
function addFilterGroup(){
	var tree=Ext.getCmp('maintree');
	var root=tree.getRootNode();
	var newNode = new Ext.tree.TreeNode({text:'',leaf:true});
	root.appendChild(newNode);
	newNode.select();
    //var editor=Ext.getCmp('maintreeeditor');
    editor.triggerEdit(newNode);
}

*/

