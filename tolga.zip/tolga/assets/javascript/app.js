﻿$(document).ready(function()
{
	var m=$.query.get('m');
	var e=$.query.get('e');
	if (m!='' && m!=undefined && m!=null && e!='' && e!=undefined && e!=null){
		var url="http://gbuspst01:8090/newdefault.aspx?moduleId="+m+"&menuId="+e+"";
		$('#appiframe').attr("src",url); 
	}

});

