var autocompletedata=null;

$(document).ready(function () {
	SearchInit();
	
    $("input.hasTitle").val(function () { return $(this).attr("title"); }).focus(function () {
        if ($(this).attr("title") == $(this).val()) {
            $(this).val("");
        }
    }).blur(function () {
        if ($(this).val() == "") {
            $(this).val($(this).attr("title"));
        }
    });
    $("#searchicon").click(function(event)
    {
    	var keyword = document.getElementById("searchinput").value;
    	if (keyword=='' || keyword=='undefined')
	     	return;
	    Search(keyword);
    });
    $('#searchinput').focus();
    $('#searchinput').keyup(function(event) {
	  if (event.keyCode == '13') {
	     var keyword=this.value;
	     if (keyword=='' || keyword=='undefined')
	     	return;
	     	Search(keyword);
	   }
	});
});

var SERVICEURL = "http://gbuspdt02/search.api/";
function SearchInit(){
	$.ajax({
	     type: "GET", //GET or POST or PUT or DELETE verb
	     url: SERVICEURL + "searchinit", 
	     data: null,
	     contentType: "json", // content type sent to server
	     dataType: "json", //Expected data format from server
	     processdata: false, //True or False
	     complete: function (data) {
	        ParseAutoComplete(data); 
	     }
	 });
}

function Search(keyword){
	location.href="result.aspx#p="+$.base64Encode(keyword);
}



function ParseAutoComplete(data){
 	var obj= jQuery.parseJSON(data.responseText);
	var sr=obj.SearchInitResult;
 	var autocomplete=new Array();
 	var autocompletefull = new Array();//autocompletee array with full parameters
 	var i=0;
 	$(sr).each(function (properties, val) {
 		autocomplete[i]=val.Keyword;
 		autocompletefull[i] = val;
 		i++;
 	});
 	autocompletedata=autocomplete;
 	BindAutoComplete(autocomplete);
 }
 
 function BindAutoComplete(data){
	 $('#searchinput').autocomplete({
		minChars: 0,
		delimiter: /(,|;)\s*/, // regex or character
		maxHeight: 130,
		zIndex: 9999,
		deferRequestBy: 0, //miliseconds
		noCache: false, //default is false, set to true to disable caching
		autoFill:true,
		// callback function:
		onSelect: function (value, data) { 
			var redirect=false;
			for(var i = 0; i<autocompletedata.length; i++)
			{
				if(value == autocompletedata[i].Keyword && autocompletedata[i].Url != '' && autocompletedata[i].Url != null)
				{
					location.href = autocompletedata[i].Url;
					redirect=true;
					break;
				}   
			}
			if (!redirect){
				Search(value);
			}
		},
		lookup: data
	});	
 }

