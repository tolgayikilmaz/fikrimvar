$(document).ready(function () {

    /* menu */
    
    $("ul.menu > li a").live("click", function (e) {
        var isSelected = $(this).parent().hasClass("selected");
        if (isSelected) {
            $(this).parent().removeClass("selected");
        }
        else {
            $(this).parent().addClass("selected");
        }
    }).eq(0).parent().addClass("selected");

    $("a.open-all-menu").click(function () {
        $("ul.menu.menu-type2 > li").addClass("selected");
    });
    $("a.close-all-menu").click(function () {
        $("ul.menu.menu-type2 > li").removeClass("selected");
    });
    /* menu */

    /* collapse */
    $("ul.collapse.collapse-type1 li").click(function () {
        var isSelected = $(this).hasClass("selected");
        $("ul.collapse.collapse-type1 li").removeClass("selected").find("a span small").html("AC");
        if (!isSelected) {
            $(this).addClass("selected").find("a span small").html("KAPAT");
        }
    });
    $("ul.collapse.collapse-type2 li").click(function (e) {
        var isSelected = $(this).hasClass("selected");
        if (isSelected) {
            if ($(e.target).parents("ul:first").is(".collapse")) {
                $(this).removeClass("selected");
            }
        }
        else {
            $(this).addClass("selected");
        }
    });
    /* collapse */

    /* tab */
    $("ul.tab li").click(function () {
        $("ul.tab li").removeClass("selected");
        $(this).addClass("selected");
        $("div.tab-zone").hide().eq($(this).index()).show();
    });
    /* tab */

    /* menubox */
    $("ul#menu > li").click(function (e) {
        $("ul#menu > li").not(this).removeClass("selected");
        var isSelected = $(this).hasClass("selected");
        if (!isSelected) {
            $(this).addClass("selected");
        }
        else {
            if ($(e.target).parents("span").is(".tabbed")) {
                $(this).removeClass("selected");
            }
        }

    });
    $(document).click(function (e) {

        if ($(e.target).closest("ul#menu").html() == null) {
            $("ul#menu li.selected").removeClass("selected");
        }
        if ($(e.target).closest("ul#othermenu").html() == null) {
            $("ul#othermenu li.selected").removeClass("selected");
        }
    });

    /* menubox */

    /* othermenu */
    $("ul#othermenu > li").click(function (e) {
        $("ul#othermenu > li").not(this).removeClass("selected").css("z-index", 1);
        var isSelected = $(this).hasClass("selected");
        if (!isSelected) {
            $(this).addClass("selected").css("z-index", 2);
        }
        else {
            /*if ($(e.target).parents("span").is(".tabbed")) {
            $(this).removeClass("selected");
            }*/
        }

    });
    /* othermenu */

    /* menusearch */
    $("input.hasTitle").focus(function () {
        if ($(this).attr("title") == $(this).val()) {
            $(this).val("");
        }
    }).blur(function () {
        if ($(this).val() == "") {
            $(this).val($(this).attr("title"));
        }
    });
    /* menusearch*/



    /* social item */
    $("div.social-feed div.social-item div.desc").live("click", function (e) {
    	GetEntryAnswers(getDocId($(this)));
    	
            	 
   
        if ($(e.target).parent().hasClass("social-item")) {
        	var isUnRead = $(this).parent().hasClass("unread")
            if (isUnRead) {
                $(this).parent().removeClass("unread");
            }
            var isSelected = $(this).parent().hasClass("selected");
            $("div.social-feed div.social-item").removeClass("selected");
            if (!isSelected) {
                $(this).parent().addClass("selected");
            }
            
            if (isUnRead && !isSelected) {
            	MarkAsRead(getDocId($(this)));
            	
            
            	
            }
        }
    });

    $("div.social-feed div.social-item ul.social-proccess li a.answer").live("click", function (e) {
    	e.preventDefault();
        if ($(this).parents("div.social-item").find("div.answer").css("display") == "none") {
            $(this).parents("div.social-item").find("div.answer").show();
            $(this).parents("div.social-item").find("div.forward").hide();
        }
        else {
            $(this).parents("div.social-item").find("div.answer").hide();
        }
    });
    $("div.social-feed div.social-item ul.social-proccess li a.forward").live("click", function (e) {
    	e.preventDefault();
        if ($(this).parents("div.social-item").find("div.forward").css("display") == "none") {
            $(this).parents("div.social-item").find("div.forward").show();
            $(this).parents("div.social-item").find("div.answer").hide();
        }
        else {
            $(this).parents("div.social-item").find("div.forward").hide();
        }
    });

    $("div.social-feed div.social-item ul.social-proccess li a.unread").live("click", function (e) {
    	e.preventDefault();
        $(this).parents("div.social-item").addClass("unread").removeClass("selected");
        MarkAsUnRead(getDocId($(this)))
    });

    $("div.social-feed div.social-item ul.social-proccess li a.unrelated").live("click", function (e) {
    	e.preventDefault();
        $(this).parents("div.social-item").removeClass("selected");
        MarkAsIrrelative(getDocId($(this)));
    });

    $("a.cancel").live("click", function (e) {
    	e.preventDefault();
        if ($(this).closest("div.answer")) {
            $(this).parents("div.answer").hide();
        }
        if ($(this).closest("div.forward")) {
            $(this).parents("div.forward").hide();
        }
    });


    /* social item */

    /* tag */
    $("ul.tag li").click(function (e) {
        e.preventDefault();
        $(this).not(".right").hide("fast");
    });
    /* tag */

    /* bullet */
    /*
    $("div.bullet").click(function (e) {
        e.preventDefault();
        var Index;
        var klassArr = ["bullet0", "bullet1", "bullet2"];
        var klass = $(this).attr("className").split(" ")[1];
        var klassIndex = parseInt(klass.split("bullet")[1]);

        $(this).removeClass(klass);

        Index = klassIndex + 1;
        if (klassIndex == klassArr.length - 1) {
            Index = 0;
        }
        $(this).addClass(klassArr[Index]);

    });
    */
    /* bullet*/

    /* star*/
    
    $("div.star").live("click", function (e) {
        e.preventDefault();
        var isStarred = $(this).hasClass("star1");
        var docId = getDocId($(this));
        if (isStarred)
        {
        	$(this).removeClass("star1");
        	MarkAsStarred(docId);
        }
        else
        {
        	$(this).addClass("star1");
        	MarkAsUnStarred(docId)
        }
    });
    
    /* star*/

    /* card */
    $("div.card").click(function (e) {
        var isCard = !$(e.target).parents("ul").hasClass("card-link");
        if (isCard) {
            var isSelected = $(this).hasClass("selected");
            $("div.card").removeClass("selected").find("img").attr("src", "assets/image/card-bg.gif");
            if (isSelected) {
                $(this).removeClass("selected").find("img").attr("src", "assets/image/card-bg.gif");
            }
            else {
                $(this).addClass("selected").find("img").attr("src", "assets/image/card-selected-bg.gif");
            }
        }
    });
    /* card */

    /* slider */
    $("div.slider ul.slider-tab li").click(function () {
        $("div.slider ul.slider-tab li span.selected").remove();
        $("div.slider div.slider-item").hide().eq($(this).index()).show();
        $("<span></span>").attr({
            className: "selected"
        }).appendTo(this);
    });
    /* slider */

    if ($("div.scroll div.social-issues").length > 0) {
        $("div.scroll div.social-issues").jScrollPane();
    }

    /* auto complete */
    
    function getDocId(object)
    {
    	if (object.attr("docid") !== undefined) return object.attr("docid");
    	{
    		
    	}
    	return object.parents("div.social-item").attr("docid");
    }
});

function setMyRegister(id, isPlus)
{
	var obj = $("#"+id).find("b");
	
	if (isPlus)
	{
    	obj.html(parseInt(obj.html())+1);
	}
	else
	{
		if (parseInt(obj.html()) > 0)
    	{
    		obj.html(parseInt(obj.html())-1);
    	}
	}
	
}

/***************/
function doIframe(){
	o = document.getElementsByTagName('iframe');
	for(i=0;i<o.length;i++){
		if (/\bautoHeight\b/.test(o[i].className)){
			setHeight(o[i]);
			addEvent(o[i],'load', doIframe);
		}
	}
}

function setHeight(e){
	var offset = $("#content").offset();
	e.height = $(document).height()-offset.top-35;
}

function addEvent(obj, evType, fn){
	if(obj.addEventListener)
	{
	obj.addEventListener(evType, fn,false);
	return true;
	} else if (obj.attachEvent){
	var r = obj.attachEvent("on"+evType, fn);
	return r;
	} else {
	return false;
	}
}

if (document.getElementById && document.createTextNode){
 addEvent(window,'load', doIframe);	
}

