﻿var treePanel=new FilterGroupTree();
MainPanelUi = Ext.extend(Ext.Panel, {
    id:'border-panel',
    layout: 'border',
    bodyBorder: false,
    height:600,
    initComponent: function() {
	    this.defaults= {
	        collapsible: false,
	        split: true,
	        animFloat: false,
	        autoHide: false,
	        useSplitTips: true,
	        bodyStyle: 'padding:15px'
	    };
	    /*
	    this.items= [{
		        title: 'Navigation',
		        region:'west',
		        collapsible: false,
		        margins: '5 0 0 0',
		        cmargins: '5 5 0 0',
		        width: 175,
		        minSize: 100,
		        maxSize: 250,
		        items: [treePanel]
	    	},{
		        title: 'Main Content',
		        collapsible: false,
		        region: 'center',
		        margins: '5 0 0 0'
	    	}];*/
	    	MainPanelUi.superclass.initComponent.call(this);
    	}
});

MainPanel = Ext.extend(MainPanelUi, {
    initComponent: function() {
        MainPanel.superclass.initComponent.call(this);
    }
});

